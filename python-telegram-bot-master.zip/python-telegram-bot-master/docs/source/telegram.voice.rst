telegram.voice module
=====================

.. automodule:: telegram.voice
    :members:
    :undoc-members:
    :show-inheritance:
