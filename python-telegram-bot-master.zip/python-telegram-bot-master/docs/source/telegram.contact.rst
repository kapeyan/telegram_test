telegram.contact module
=======================

.. automodule:: telegram.contact
    :members:
    :undoc-members:
    :show-inheritance:
