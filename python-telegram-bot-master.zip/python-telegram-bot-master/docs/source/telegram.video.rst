telegram.video module
=====================

.. automodule:: telegram.video
    :members:
    :undoc-members:
    :show-inheritance:
