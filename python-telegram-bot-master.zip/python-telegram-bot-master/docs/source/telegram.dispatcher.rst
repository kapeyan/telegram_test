telegram.dispatcher module
=========================

.. automodule:: telegram.dispatcher
    :members:
    :undoc-members:
    :show-inheritance:
