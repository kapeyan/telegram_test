telegram.choseninlineresult module
==================================

.. automodule:: telegram.choseninlineresult
    :members:
    :undoc-members:
    :show-inheritance:
