telegram.inputfile module
=========================

.. automodule:: telegram.inputfile
    :members:
    :undoc-members:
    :show-inheritance:
