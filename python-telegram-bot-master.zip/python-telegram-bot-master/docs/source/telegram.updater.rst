telegram.updater module
=========================

.. automodule:: telegram.updater
    :members:
    :undoc-members:
    :show-inheritance:
