telegram.emoji module
=====================

.. automodule:: telegram.emoji
    :members:
    :undoc-members:
    :show-inheritance:
