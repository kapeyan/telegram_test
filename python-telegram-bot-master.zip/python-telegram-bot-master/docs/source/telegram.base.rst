telegram.base module
====================

.. automodule:: telegram.base
    :members:
    :undoc-members:
    :show-inheritance:
