telegram.bot module
===================

.. automodule:: telegram.bot
    :members:
    :undoc-members:
    :show-inheritance:
